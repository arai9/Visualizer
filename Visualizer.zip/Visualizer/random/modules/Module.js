USERNAME = "John";
PASSWORD = "abc";
function validateUser () {
  
  var userName = frmLogin.txtUserName.text;
  var password = frmLogin.txtPassword.text;


if (userName == USERNAME && password==PASSWORD)
  {
    createWidget();
    Form1.show();
    
  }
else
  {
    var basicConf = {message: "Username or Password is Invalid. Please, try again.",
                     alertType: constants.ALERT_TYPE_INFO, alertTitle: "Validation",
                    yesLabel: "OK",alertHandler: alertCallback};
    var pspConf = {};
    kony.ui.Alert(basicConf,pspConf);
  }
}
function createWidget () {
  //var lblBasic = {id:label11112 , skin:"lblWelcome", text:"Welcome !", isVisible:true};
  //var lblLayout = {top:160, left:100};
  //var lblPsp = {renderAsAnchor:true,wrapping:constants.WIDGET_TEXT_WORD_WRAP};
  //var lbl = new kony.ui.Label(lblBasic, lblLayout, lblPsp);
  
  //Form1.flx1.add(lbl);
  Form1.flx1.label11112.text="Hello "+USERNAME + "!";
}
function defineLoginOnClick()
{
  frmLogin.btnLogin.onClick = validateUser();
}
function alertCallback(){
  
} //Type your code here