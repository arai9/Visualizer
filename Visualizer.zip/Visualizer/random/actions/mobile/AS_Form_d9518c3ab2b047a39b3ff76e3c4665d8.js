function AS_Form_d9518c3ab2b047a39b3ff76e3c4665d8(eventobject) {
    frmLogin.txtUserName.text = "";
    frmLogin.txtPassword.text = "";
}