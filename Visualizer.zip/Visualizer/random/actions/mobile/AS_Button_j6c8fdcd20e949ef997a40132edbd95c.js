function AS_Button_j6c8fdcd20e949ef997a40132edbd95c(eventobject) {
    validateUser.call(this);
    Form1.show();
}