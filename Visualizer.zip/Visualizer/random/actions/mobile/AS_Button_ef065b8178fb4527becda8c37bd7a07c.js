function AS_Button_ef065b8178fb4527becda8c37bd7a07c(eventobject) {
    validateUser.call(this);
    Form1.show();
}