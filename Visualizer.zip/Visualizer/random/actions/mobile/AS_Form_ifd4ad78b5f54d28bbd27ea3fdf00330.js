function AS_Form_ifd4ad78b5f54d28bbd27ea3fdf00330(eventobject) {
    frmLogin.btnLogin.onClick = function chkUser() {
        validateUser();
    };
}